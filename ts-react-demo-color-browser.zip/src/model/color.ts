export interface color {
    red : number;
    green : number;
    blue : number;
}