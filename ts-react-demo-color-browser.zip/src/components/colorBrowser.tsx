import * as React from 'react';
import {color} from '../model/color';

interface Props {
    color : color;
}

export const ColorBrowser = (props : Props) => {
    const divStyle : React.CSSProperties = {
        width : '11rem',
        height : '3rem',
        backgroundColor : `rgb(${props.color.red}, ${props.color.green},${props.color.blue})`

    };
    return <div style = {divStyle}> Hello Dev !! </div>
}