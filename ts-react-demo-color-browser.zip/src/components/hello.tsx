import * as React from 'react';

export const HelloComponent = () => {
    return <h1>Welcome Devs !!!</h1>
}