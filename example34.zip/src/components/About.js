import React from 'react'

const About =() => {
    return (
        <div>
            <div className= "container">
                <h4 className = "center" > About</h4>
                <p> SOme text here to test the About page</p>
            </div>
        </div>
    )
}
export default About;