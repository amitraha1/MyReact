import React from 'react'

const Contact =() => {
    return (
        <div>
            <div className= "container">
                <h4 className = "center" > Contact</h4>
                <p> SOme text here to test the Contact page</p>
            </div>
        </div>
    )
}
export default Contact;