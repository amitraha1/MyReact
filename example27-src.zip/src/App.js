import React, {Component} from "react";
import Ninjas from "./Ninjas";
import AddNinja from "./AddNinja";
import './App.css';

class App extends Component {
    state = {
        ninjas : [
            {name : "Ram", age : "34", belt : "blk", id : 1},
            {name : "Raj", age : "24", belt : "green", id : 2},
            {name : "Rakesh", age : "14", belt : "red", id : 3}
        ]
    }

    addNinja = (ninja) => {
        ninja.id = Math.random();
        let ninjas = [...this.state.ninjas, ninja];
        this.setState(
            {
                ninjas : ninjas
            }
        )
    }

    deleteNinja = (id) => {
        let ninjas = this.state.ninjas.filter( ninja => {
            return ninja.id !== id
        });
        this.setState(
            {
                ninjas : ninjas
            }
        )
    }
    render() {
        return (
            <div className="App"> 
            <p> Welcome Developers </p>
            <br />
                <h3> Custom Sub Component with state and properties</h3>
                <Ninjas ninjas= {this.state.ninjas}  deleteNinja={this.deleteNinja}/>

                <AddNinja addNinja={this.addNinja}/>
            </div>
        );
    }
}

export default App;