class App extends React.Component {
    state = {
        name : "Ram",
        age : 30
    }

    handleMouseOver(e) {
        console.log(e.target, e.pageX);
    }

    handleClick = (e)  => {
        console.log(e.target);
        console.log(this.state);
        this.setState(
            {
                name : 'Yoshi'
            }
        )
    }

    handleCopy(e) {
        console.log("Try being original for once ");
    }

    handleChange = (e) => {
        this.setState( {
            name : e.target.value
        }
        );
    }

    handleSubmit = (e) => {
        e.preventDefault();
        console.log('form submitted', this.state);
    }
    render() {
        return (
            <div className="app-content">
                <h1> Hello Developers </h1>
                <p> My name is : {this.state.name } and I am { this.state.age } </p>
                <button onClick={this.handleClick}> Click Me</button>
                <button onMouseOver={this.handleMouseOver}> Hover Me </button>
                <p onCopy = {this.handleCopy}> What ? </p>

                <form onSubmit={this.handleSubmit}>
                <label for="username">Username:</label>
                    <input type="text" onChange={this.handleChange} ></input>
                    <input type="text" onChange={this.handleChange} ></input>
                    <button>Submit</button>

                </form>

            </div>
        )
    }
}


//ReactDOM.render(<App />, document.getElementById('app'));

const domContainer = document.querySelector("#app")
const root = ReactDOM.createRoot(domContainer);
root.render(<App />);