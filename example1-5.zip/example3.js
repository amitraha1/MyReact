var array = [1,2,3,4]
const sum = (acc, value) => acc+value;
const product = (acc,value) => acc*value;

var sumOFArrayElem = array.reduce(sum,0);
var mulOFArrayElem = array.reduce(product,1);

console.log("Sum", sumOFArrayElem);
console.log("Multiply", mulOFArrayElem);

var sumOFArrayElem1 = array.reduce((acc,value) => acc+ value,0);
var mulOFArrayElem1 = array.reduce((acc,value) => acc* value,1);

console.log("Sum", sumOFArrayElem1);
console.log("Multiply", mulOFArrayElem1);

const sum1 = (acc, value) => {
    const result = acc+ value;
    console.log(acc,'plus', value, 'is ', result);
    return result;
}

var sumOFArrayElements = array.reduce(sum1,0);

