function f() {

var x=1;
let y =2;
const z=3;

{
    var x= 100;
    let y = 200;
    const z = 300;

    console.log('x :'+x);
    console.log('y :'+y);
    console.log('z :'+z);
}
console.log('x outside :'+x);
console.log('y outside :'+y);
console.log('z outside :'+z);
}
f();