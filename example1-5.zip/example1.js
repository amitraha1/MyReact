var colors = ['green','blue','red','pink'];

function print(val) {
    console.log(val);
}

colors.forEach(print);

function capitalize(val) {
    return val.toUpperCase();
}

var capitalizedColors = colors.map(capitalize);
console.log(capitalizedColors);