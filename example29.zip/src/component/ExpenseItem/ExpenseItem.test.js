import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ExpenseItem from './ExpenseItem';

describe('<ExpenseItem />', () => {
  test('it should mount', () => {
    render(<ExpenseItem />);

    const ExpenseItem = screen.getByTestId('ExpenseItem');

    expect(ExpenseItem).toBeInTheDocument();
  });
});