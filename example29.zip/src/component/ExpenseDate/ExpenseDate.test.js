import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ExpenseDate from './ExpenseDate';

describe('<ExpenseDate />', () => {
  test('it should mount', () => {
    render(<ExpenseDate />);

    const ExpenseDate = screen.getByTestId('ExpenseDate');

    expect(ExpenseDate).toBeInTheDocument();
  });
});