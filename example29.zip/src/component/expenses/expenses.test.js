import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import expenses from './expenses';

describe('<expenses />', () => {
  test('it should mount', () => {
    render(<expenses />);

    const expenses = screen.getByTestId('expenses');

    expect(expenses).toBeInTheDocument();
  });
});