const e = React.createElement;

class BvrButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = {liked : false};
    }

    render() {
        if(this.state.liked) {
            return 'this is BVR button component';
        }

        return e(
            'button',{
                onclick : () => this.setState({liked : true})
            },
            'BVR'
        )
    }
}

const domContainer = document.querySelector("#bvr_button_container")
const root = ReactDOM.createRoot(domContainer);
root.render(e(BvrButton));