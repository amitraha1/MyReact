const Products = () => {
    return (
    <section>
    <h1> The Product Page </h1>;
    <ul>
        <li> Book</li>
        <li> Carpet</li>
        <li>online book</li>
    </ul>
    </section>
    )
};

export default Products;