import {FetchData} from './demo';

function App() {
  return(
    <div>
      <FetchData />
    </div>
  );
}
export default App;