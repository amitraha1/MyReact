import classes from './HeaderCardButton.module.css';

const HeaderCartButton = (props) => {
    return (
    <button className={classes.button}>
        <span className={classes.button}>
        <CartIcon />
        </span>
        <span> your card</span>
        <span className={classes.badge} >3</span>
    </button>
    );
}