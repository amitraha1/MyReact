import React from 'react';

const useModel = (initData) => {
    const [data, setData] = React.useState(initData);

    const updateData = (newData) => {
        setData({...data , ...newData});
    };

    return [data, updateData];
};

export const MyComponent = props => {
    // const [filter, setFilter] = React.useState("");
    // const [userSchema, setUserSchema] = React.useState([]);

    const [model, updateModel] = useModel([]); //{name : 'amit', username : 'a', email : 'a@a.com' });

    React.useEffect(() => {
        fetch(`https://jsonplaceholder.typicode.com/users`)
        .then(response => response.json())
        .then(json => updateModel(json));
    },[]);

    return (
        <div>
            {/* <input value = {filter} onChange = {e  => setFilter(e.target.value)} /> */}
            <ul>
                {console.log(model)}
                {console.log(model[0])}
                
                {/* <View style={style.rowStyle}> */}
                {Object.entries(model).map (([key,value]) => (
                        //  <li key={key}> {value.name}   {value.username}  {value.email}</li>
                        //  <Cell data={key} />,
                        //  <Cell data={value.name} />,
                        //  <Cell data={value.username} />,
                        //  <Cell data={value.email} />
                        <table>
                        <tr>
                          <th>{key}</th>
                          <th />
                          <th> {value.name} </th>
                          <th />
                          <th> {value.username} </th>
                          <th />
                          <th> {value.email} </th>
                        </tr>
                        </table> 
                ))}
                {/* </View> */}
                
                
                
                
       
            
            
                {/* {  model.map((user,index) =>
                    <li key={index}> {user.name}</li>
                ) } */}
            </ul>
        </div>
    );

}